"""
pipeline.py — fully generic fairness pipeline
Works for any CSV with any column names.
User only needs to specify: target_col + sensitive_col.
Everything else is auto-detected.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
from fairlearn.reductions import ExponentiatedGradient, DemographicParity
from fairlearn.postprocessing import ThresholdOptimizer
from fairlearn.metrics import (
    MetricFrame,
    demographic_parity_difference,
    demographic_parity_ratio,
    equalized_odds_difference,
)

# ── module-level state ───────────────────────────────────────────────────
_state = {
    "baseline":          None,
    "reweighted_model":  None,
    "threshold_model":   None,
    "X_test":            None,
    "y_test":            None,
    "A_test":            None,
    "A_test_raw":        None,   # original string labels (e.g. "Female", "Male")
    "feature_cols":      None,
    "target_col":        None,
    "sensitive_col":     None,
    "sensitive_groups":  None,   # unique values in sensitive col
    "sensitive_encoder": None,   # LabelEncoder for sensitive col
    "scaler":            None,
    "label_encoders":    {},
    "trained":           False,
    "domain":            None,   # "jobs" / "banking" / "custom" — just a label
}


# ── STEP 1: AUTO-DETECT COLUMNS ─────────────────────────────────────────

def detect_columns(df: pd.DataFrame, target_col: str, sensitive_col: str) -> list:
    """
    Given a DataFrame and the two special columns (target + sensitive),
    returns everything else as feature columns — automatically.

    Skips:
      - target_col (what we're predicting)
      - sensitive_col (protected attribute — never a model feature)
      - id-like columns (all unique strings, or column name contains "id")
      - columns with >50% nulls
    """
    exclude = {target_col, sensitive_col}

    feature_cols = []
    for col in df.columns:
        if col in exclude:
            continue
        # Skip obvious ID columns
        id_hints = ["id", "name", "ref", "code", "num", "index", "uuid", "key"]
        if any(h in col.lower() for h in id_hints) and df[col].nunique() > 0.9 * len(df):
            continue
        # Skip columns with >50% missing
        if df[col].isnull().mean() > 0.5:
            continue
        # Skip columns that are all unique (likely free-text / IDs)
        if df[col].dtype == object and df[col].nunique() == len(df):
            continue
        feature_cols.append(col)

    return feature_cols


# ── STEP 2: ENCODE SENSITIVE COLUMN (any type) ───────────────────────────

def encode_sensitive(series: pd.Series):
    """
    Handles any sensitive column type:
      - String/categorical (gender, ethnicity) → LabelEncoder → integers
      - Numeric continuous (age) → binned into groups (e.g. 22-35, 36-50, 51+)
    
    Returns:
      encoded  : numpy int array
      encoder  : the LabelEncoder (or None if binned)
      groups   : list of unique group labels (strings, for reporting)
      raw      : original string labels per row
    """
    if series.dtype == object or series.dtype.name in ("category", "string") or pd.api.types.is_string_dtype(series):
        # Categorical: just label-encode
        le = LabelEncoder()
        encoded = le.fit_transform(series.astype(str).str.strip())
        groups  = list(le.classes_)
        raw     = series.astype(str).str.strip().values
        return encoded, le, groups, raw

    else:
        # Numeric (e.g. age): bin into meaningful groups
        # Use quartiles so it works for any numeric range
        labels = ["Group_Q1", "Group_Q2", "Group_Q3", "Group_Q4"]
        binned = pd.qcut(series, q=4, labels=labels, duplicates="drop")
        le = LabelEncoder()
        encoded = le.fit_transform(binned.astype(str))
        groups  = list(le.classes_)
        raw     = binned.astype(str).values
        return encoded, le, groups, raw


# ── STEP 3: PREPROCESS (generic) ────────────────────────────────────────

def load_and_preprocess(df: pd.DataFrame, target_col: str,
                        sensitive_col: str, feature_cols: list):
    """
    Generic preprocessing — works for any dataset.
    Encodes categoricals, scales features, encodes sensitive col.
    """
    df = df.copy()
    df.dropna(subset=[target_col, sensitive_col] + feature_cols, inplace=True)

    # Encode non-numeric feature columns
    label_encoders = {}
    for col in feature_cols:
        if df[col].dtype == object or pd.api.types.is_string_dtype(df[col]):
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            label_encoders[col] = le

    # Encode target (must be 0/1)
    if df[target_col].dtype == object:
        # Try to detect positive label (yes/true/1/approved/hired etc.)
        pos_keywords = ["yes", "true", "1", "approved", "hired",
                        "accept", "positive", "readmit"]
        unique_vals = df[target_col].str.lower().str.strip().unique()
        pos_label = next(
            (v for v in unique_vals if any(k in v for k in pos_keywords)),
            unique_vals[0]   # fallback: first value = positive
        )
        df[target_col] = (df[target_col].str.lower().str.strip() == pos_label).astype(int)

    # Encode sensitive column
    sensitive_encoded, sensitive_encoder, groups, raw = encode_sensitive(df[sensitive_col])

    X = df[feature_cols].values.astype(float)
    y = df[target_col].values.astype(int)

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    return X_scaled, y, sensitive_encoded, raw, scaler, label_encoders, sensitive_encoder, groups


# ── STEP 4: TRAIN ALL THREE MODELS ──────────────────────────────────────

def train_pipeline(df: pd.DataFrame, target_col: str,
                   sensitive_col: str, domain: str = "custom") -> dict:
    """
    Main entry point called by POST /upload.
    Accepts any CSV + column names → trains 3 models → returns audit.
    """
    # Auto-detect features
    feature_cols = detect_columns(df, target_col, sensitive_col)
    if len(feature_cols) == 0:
        raise ValueError("No usable feature columns detected in this CSV.")

    (X, y, A, A_raw,
     scaler, label_encoders,
     sensitive_encoder, groups) = load_and_preprocess(df, target_col, sensitive_col, feature_cols)

    X_train, X_test, y_train, y_test, A_train, A_test, Araw_train, Araw_test = train_test_split(
        X, y, A, A_raw, test_size=0.3, random_state=42, stratify=y
    )

    # Baseline
    baseline = LogisticRegression(max_iter=1000, random_state=42)
    baseline.fit(X_train, y_train)

    # Reweighting — ExponentiatedGradient
    base_estimator = LogisticRegression(max_iter=1000, solver="liblinear", random_state=42)
    reweighted_model = ExponentiatedGradient(
        estimator=base_estimator,
        constraints=DemographicParity(difference_bound=0.05),
        eps=0.05,
    )
    reweighted_model.fit(X_train, y_train, sensitive_features=A_train)

    # Threshold calibration — ThresholdOptimizer
    threshold_model = ThresholdOptimizer(
        estimator=baseline,
        constraints="demographic_parity",
        objective="balanced_accuracy_score",
        predict_method="predict_proba",
    )
    threshold_model.fit(X_train, y_train, sensitive_features=A_train)

    # Save state
    _state.update({
        "baseline":          baseline,
        "reweighted_model":  reweighted_model,
        "threshold_model":   threshold_model,
        "X_test":            X_test,
        "y_test":            y_test,
        "A_test":            A_test,
        "A_test_raw":        Araw_test,
        "feature_cols":      feature_cols,
        "target_col":        target_col,
        "sensitive_col":     sensitive_col,
        "sensitive_groups":  groups,
        "sensitive_encoder": sensitive_encoder,
        "scaler":            scaler,
        "label_encoders":    label_encoders,
        "trained":           True,
        "domain":            domain,
    })

    return get_audit()


# ── METRICS ─────────────────────────────────────────────────────────────

def _compute_metrics(label: str, y_true, y_pred, A, A_raw, groups) -> dict:
    """
    Returns per-group approval rates + fairness metrics as a dict.
    Works for any number of groups (not just Male/Female).
    """
    acc = float(accuracy_score(y_true, y_pred))
    dpd = float(demographic_parity_difference(y_true, y_pred, sensitive_features=A))
    dpr = float(demographic_parity_ratio(y_true, y_pred, sensitive_features=A))
    eod = float(equalized_odds_difference(y_true, y_pred, sensitive_features=A))

    # Per-group approval rates — works for any number of groups
    mf = MetricFrame(
        metrics={"approval_rate": lambda yt, yp: float(yp.mean())},
        y_true=y_true,
        y_pred=y_pred,
        sensitive_features=A_raw,   # use raw labels for readable group names
    )
    group_rates = {
        str(grp): round(float(rate), 3)
        for grp, rate in mf.by_group["approval_rate"].items()
    }

    return {
        "model":                         label,
        "accuracy":                      round(acc, 3),
        "group_approval_rates":          group_rates,   # e.g. {"Female": 0.17, "Male": 0.53}
        "disparate_impact_ratio":        round(dpr, 3),
        "demographic_parity_difference": round(dpd, 3),
        "equalized_odds_difference":     round(eod, 3),
        "legal_pass":                    bool(dpr >= 0.8),
        "legal_threshold":               "EEOC 80% rule: DI ratio >= 0.80",
    }


# ── AUDIT ────────────────────────────────────────────────────────────────

def get_audit() -> dict:
    if not _state["trained"]:
        raise RuntimeError("No dataset uploaded yet. Call POST /upload first.")

    X_test  = _state["X_test"]
    y_test  = _state["y_test"]
    A_test  = _state["A_test"]
    A_raw   = _state["A_test_raw"]
    groups  = _state["sensitive_groups"]

    y_pred_baseline   = _state["baseline"].predict(X_test)
    y_pred_reweighted = _state["reweighted_model"].predict(X_test)
    y_pred_threshold  = _state["threshold_model"].predict(X_test, sensitive_features=A_test)

    return {
        "domain":        _state["domain"],
        "target_col":    _state["target_col"],
        "sensitive_col": _state["sensitive_col"],
        "groups_found":  groups,
        "feature_cols":  _state["feature_cols"],
        "results": [
            _compute_metrics("Baseline (biased)",        y_test, y_pred_baseline,   A_test, A_raw, groups),
            _compute_metrics("Reweighting (Stage 1)",    y_test, y_pred_reweighted,  A_test, A_raw, groups),
            _compute_metrics("Threshold cal. (Stage 3)", y_test, y_pred_threshold,   A_test, A_raw, groups),
        ]
    }


# ── SINGLE PREDICTION ────────────────────────────────────────────────────

def predict_applicant(features: dict, sensitive_value: str) -> dict:
    """
    features       : dict of {col_name: value} — any domain's feature set
    sensitive_value: raw string value of sensitive col (e.g. "Female", "Asian", "Group_Q2")
    """
    if not _state["trained"]:
        raise RuntimeError("No dataset uploaded yet.")

    feature_cols = _state["feature_cols"]
    scaler       = _state["scaler"]
    le_map       = _state["label_encoders"]
    sens_enc     = _state["sensitive_encoder"]

    # Build feature vector in correct column order
    x_raw = []
    for col in feature_cols:
        val = features.get(col)
        if val is None:
            raise ValueError(f"Missing feature: '{col}'")
        # Encode string features
        if col in le_map:
            val = int(le_map[col].transform([str(val)])[0])
        x_raw.append(float(val))

    x_scaled = scaler.transform([x_raw])

    # Encode sensitive value
    try:
        A_val = int(sens_enc.transform([sensitive_value])[0])
    except Exception:
        A_val = 0   # fallback if unseen group

    A_arr = np.array([A_val])

    baseline_pred   = int(_state["baseline"].predict(x_scaled)[0])
    baseline_prob   = round(float(_state["baseline"].predict_proba(x_scaled)[0][1]), 3)
    reweighted_pred = int(_state["reweighted_model"].predict(x_scaled)[0])
    threshold_pred  = int(_state["threshold_model"].predict(x_scaled, sensitive_features=A_arr)[0])

    target = _state["target_col"]
    pos_label = "APPROVED" if any(k in target.lower() for k in
                                  ["loan","approv","hire","hired","admit","scholar"]) else "POSITIVE"
    neg_label = "REJECTED" if pos_label == "APPROVED" else ("NOT HIRED" if "hire" in target.lower() else "NEGATIVE")

    return {
        "sensitive_col":   _state["sensitive_col"],
        "sensitive_value": sensitive_value,
        "target_col":      target,
        "baseline":             {"decision": baseline_pred, "probability": baseline_prob,
                                 "label": pos_label if baseline_pred else neg_label},
        "reweighted":           {"decision": reweighted_pred,
                                 "label": pos_label if reweighted_pred else neg_label},
        "threshold_calibrated": {"decision": threshold_pred,
                                 "label": pos_label if threshold_pred else neg_label},
        "bias_detected": baseline_pred != reweighted_pred or baseline_pred != threshold_pred,
        "note": "bias_detected=True means the baseline treated this person differently due to bias."
    }


# ── SCHEMA (for dynamic frontend forms) ─────────────────────────────────

def get_schema() -> dict:
    """
    Returns detected column info so the frontend can build its form dynamically.
    No hardcoding needed on the frontend side.
    """
    if not _state["trained"]:
        raise RuntimeError("No dataset uploaded yet.")
    return {
        "feature_cols":   _state["feature_cols"],
        "target_col":     _state["target_col"],
        "sensitive_col":  _state["sensitive_col"],
        "sensitive_groups": _state["sensitive_groups"],
        "domain":         _state["domain"],
    }
