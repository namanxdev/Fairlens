"""
main.py — generic FastAPI app
Works for jobs, banking, healthcare, education — any CSV.
User only needs to tell us: target_col + sensitive_col.
"""

import io
import pandas as pd
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from pipeline import (
    train_pipeline, get_audit, get_schema,
    predict_applicant, _state
)

app = FastAPI(
    title="AI Fairness Auditor — Universal",
    description="""
Upload ANY dataset (jobs, loans, healthcare, education).
Just tell us which column is the target and which is the sensitive attribute.
We handle everything else automatically.
    """,
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Health check ─────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {
        "status":  "running",
        "trained": _state["trained"],
        "domain":  _state.get("domain"),
        "message": "POST /upload with target_col + sensitive_col to begin"
    }


# ── POST /upload ──────────────────────────────────────────────────────────
@app.post("/upload")
async def upload_dataset(
    file:          UploadFile = File(...),
    target_col:    str        = Form(...),   # e.g. "hired", "loan_approved", "readmitted"
    sensitive_col: str        = Form(...),   # e.g. "gender", "age", "ethnicity"
    domain:        str        = Form("custom"),  # just a label: "jobs"/"banking"/"healthcare"
):
    """
    Upload any CSV file.

    Required form fields:
    - **file**: the CSV
    - **target_col**: column name of what you're predicting (must be 0/1 or Yes/No)
    - **sensitive_col**: protected attribute column (gender, age, ethnicity, race, etc.)
    - **domain**: optional label — jobs / banking / healthcare / education / custom

    Returns full fairness audit immediately after training.
    """
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files accepted.")

    contents = await file.read()
    try:
        df = pd.read_csv(io.StringIO(contents.decode("utf-8")))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse CSV: {e}")

    # Validate columns exist
    if target_col not in df.columns:
        raise HTTPException(
            status_code=400,
            detail=f"target_col '{target_col}' not found. Available: {list(df.columns)}"
        )
    if sensitive_col not in df.columns:
        raise HTTPException(
            status_code=400,
            detail=f"sensitive_col '{sensitive_col}' not found. Available: {list(df.columns)}"
        )
    if len(df) < 50:
        raise HTTPException(status_code=400, detail="Dataset too small (need at least 50 rows).")

    try:
        result = train_pipeline(df, target_col, sensitive_col, domain)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Training failed: {str(e)}")

    return result


# ── GET /audit ────────────────────────────────────────────────────────────
@app.get("/audit")
def audit():
    """
    Fairness metrics for all 3 models on the test set.
    Returns per-group approval rates for however many groups exist in your sensitive col.
    """
    if not _state["trained"]:
        raise HTTPException(status_code=400, detail="No dataset loaded. POST /upload first.")
    return get_audit()


# ── GET /schema ───────────────────────────────────────────────────────────
@app.get("/schema")
def schema():
    """
    Returns the auto-detected column structure of the uploaded dataset.
    Frontend uses this to dynamically build the prediction form — no hardcoding needed.

    Example response:
    {
      "feature_cols": ["cibil_score", "income", "employment_years", ...],
      "target_col": "loan_approved",
      "sensitive_col": "gender",
      "sensitive_groups": ["Female", "Male"],
      "domain": "banking"
    }
    """
    if not _state["trained"]:
        raise HTTPException(status_code=400, detail="No dataset loaded. POST /upload first.")
    return get_schema()


# ── POST /predict ─────────────────────────────────────────────────────────
@app.post("/predict")
def predict(body: dict):
    """
    Predict for a single applicant using all 3 models.

    Send a JSON body with:
    - All feature columns (get the list from GET /schema)
    - The sensitive column value (e.g. "Female", "Asian", "Group_Q2")

    Example for banking dataset:
    {
      "cibil_score": 720,
      "monthly_income": 62000,
      "loan_amount": 400000,
      "employment_years": 5,
      "existing_loans": 1,
      "has_property": 1,
      "age": 34,
      "sensitive_value": "Female"
    }

    Returns decision from all 3 models + whether bias was detected.
    """
    if not _state["trained"]:
        raise HTTPException(status_code=400, detail="No dataset loaded. POST /upload first.")

    sensitive_value = body.pop("sensitive_value", None)
    if sensitive_value is None:
        raise HTTPException(
            status_code=400,
            detail="Missing 'sensitive_value' field. "
                   f"Should be one of: {_state['sensitive_groups']}"
        )

    try:
        result = predict_applicant(body, str(sensitive_value))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return result


# ── GET /status ───────────────────────────────────────────────────────────
@app.get("/status")
def status():
    return {
        "trained":       _state["trained"],
        "domain":        _state.get("domain"),
        "target_col":    _state.get("target_col"),
        "sensitive_col": _state.get("sensitive_col"),
        "groups":        _state.get("sensitive_groups"),
        "n_features":    len(_state["feature_cols"]) if _state["feature_cols"] else 0,
    }
